<?php $__env->startSection('content'); ?>
    

        <div class="content-wrapper ">
            <div class="row grid-margin stretch-card">
            <div class="col-md-12 ">
        

        <div class="card">
            <div class="card-header">
                <h2>Edit Assign Subject</h2>
            </div>
            <div class="card-body">

        
        <form action="<?php echo e(route('assign_subjects.update', $assignSubject->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="teacher_id">Teacher</label>
                <select name="teacher_id" id="teacher_id" class="form-control" required>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($teacher->id); ?>" <?php echo e($teacher->id == $assignSubject->teacher_id ? 'selected' : ''); ?>>
                            <?php echo e($teacher->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="class_group_id">Class Group</label>
                <select name="class_group_id" id="class_group_id" class="form-control" required>
                    <?php $__currentLoopData = $classGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($classGroup->id); ?>" <?php echo e($classGroup->id == $assignSubject->class_group_id ? 'selected' : ''); ?>>
                            <?php echo e($classGroup->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="section_id">Section</label>
            <select name="section_id" id="section_id" class="form-control" required>
                <option value="">Select Section</option>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($section->id); ?>" <?php echo e($section->id == $assignSubject->section_id ? 'selected' : ''); ?>>
                    <?php echo e($section->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
            <div class="form-group">
                <label for="subject_id">Subject</label>
                <select name="subject_id" id="subject_id" class="form-control" required>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>" <?php echo e($subject->id == $assignSubject->subject_id ? 'selected' : ''); ?>>
                            <?php echo e($subject->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>

            </div>

        </div>

            </div>

            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>

<script>
    $(document).ready(function() {
        $('#class_group_id').change(function() {
            console.log('senmd');
            var classGroupId = $(this).val();
            $.ajax({
                url: "<?php echo e(route('sections.by_class_group')); ?>",
                type: 'POST',
                data: { class_group_id: classGroupId, _token: '<?php echo e(csrf_token()); ?>' },
                success: function(response) {
                    $('#section_id').empty();
                    $('#section_id').append('<option value="">Select Section</option>');
                    $.each(response, function(key, value) {
                        $('#section_id').append('<option value="' + value.id + '">' + value.name + '</option>');
                    });
                }
            });
        });
    });
</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/assign_subjects/edit.blade.php ENDPATH**/ ?>