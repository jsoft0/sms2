<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">



        <div class="row">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Class</h4>
                        <form action="<?php echo e(route('class.update',$class->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">

                                    <label for="t_name">Teacher ID *</label>
                                    <input id="t_name" name="teacher_id" type="text" class="form-control"
                                        placeholder="Teacher Id" value="<?php echo e($class->teacher_id); ?>">

                                </div>

                                <div class="col-md-6">

                                    <label for="t_name">Teacher Name *</label>
                                    <input id="t_name" name="name" type="text" class="form-control"
                                        placeholder="Teacher Name" value="<?php echo e($class->name); ?>">

                                </div>


                                <div class="col-md-6 mt-3 ">
                                    <?php
                                    $classNames=['Prep','Nursery','One','Two','Three','Four','Five',]

                                    ?>
                                    <label for="name">Class *</label>
                                    <select name="class" class="form-control">
                                        <option value="none">Default select</option>

                                        <?php $__currentLoopData = $classNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $className): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($className); ?>" <?php echo e(($class->class==$className) ? 'selected' : ''); ?>><?php echo e($className); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>



                                <div class="col-md-6 mt-3">

                                    <?php

                                $sections=['a','b','c']

                                    ?>


                                    <label for="section">Section *</label>
                                    <select name="section" id="section" class="form-control">
                                        <option>Default select</option>

                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($section); ?>" <?php echo e(($class->section==$section) ? 'selected' : ''); ?> > <?php echo e($section); ?>

                                        </option>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>


                                <div class="col-md-6 mt-3">

                                    <?php

                                        $subjects=['English','Math','General Science']

                                    ?>

                                    <label for="subject">Subject *</label>
                                    <select name="subject" class="form-control">

                                        <option>Default select</option>

                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($subject); ?>" <?php echo e(($class->subject==$subject ? 'selected' : '')); ?>> <?php echo e($subject); ?>

                                        </option>


                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                                    </select>
                                </div>


                                <div class="col-12 mt-3">

                                    <button class="btn btn-primary" type="submit">Save</button>
                                    <button class="btn btn-primary" type="reset">Reset</button>

                                </div>


                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/class/edit.blade.php ENDPATH**/ ?>