<?php $__env->startPush('js'); ?>


<script>
    $(document).ready(function() {
        $('select[name="select-class"]').change(function() {
            var classId = $(this).val();
            if (classId) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('attendence.sections')); ?>",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        class_id: classId
                    },
                    success: function(res) {
                        if (res) {
                            $("#sectionContainer").html(res);
                        } else {
                            $("#sectionContainer").empty();
                        }
                    }
                });
            } else {
                $("#sectionContainer").empty();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<style>
    .form-check .form-check-label{
        margin-left: 2px;
    }
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>



    <div class="content-wrapper ">


        <div class="row">

            <div class="col-12 mt-3">
                <h2>Attendance Form</h2>

                <form action="<?php echo e(route('attendence.create')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        

                        


                        

                        <div class="col-md-4">
                            <select class="custom-select" name="select-class" id="select-class">
                                <option selected>Select Class</option>
                                <?php
                                    $classes = App\Models\ClassGroup::all(); // Replace 'ClassName' with your actual class model name
                                ?>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($class->id); ?>"><?php echo e($class->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-4" id="sectionContainer">
                            <select class="custom-select" name="select-section" id="select-section">
                                <option selected>Select Section</option>
                            </select>
                        </div>

                        




                        <div class="col-md-4">
                            <button class="btn btn-primary" type="submit">Search</button>




                        </div>


                    </div>
                </form>

                <form class="mt-3" method="POST" action="<?php echo e(route('attendence.store')); ?>">

                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-md-6">
                            <h2>attendence Date</h2>
                            <input type="date" name="attendance_date" class="form-control" required>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6 mt-3">
                            <h2>Name</h2>
                        </div>
                        <div class="col-md-6">
                            <h2 class="ml-3">attendence</h2>
                        </div>
                    </div>
                    <?php if(isset($students)): ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-row align-items-center">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="student_id[]" class="form-control"
                                            value="<?php echo e($student->id); ?>" hidden>
                                        <input type="text" name="student_name[]" class="form-control"
                                            value="<?php echo e($student->name); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="checkbox ml-3 form-group">
                                        <div class="form-check form-check-inline d-inline">
                                            <input class="form-check-input d-inline" type="radio"
                                                name="attendance[<?php echo e($student->id); ?>]" id="present<?php echo e($student->id); ?>"
                                                value="present">
                                            <label class="form-check-label d-inline " for="present<?php echo e($student->id); ?>">Present</label>
                                        </div>
                                        <div class="form-check form-check-inline d-inline">
                                            <input class="form-check-input d-inline" type="radio"
                                                name="attendance[<?php echo e($student->id); ?>]" id="absent<?php echo e($student->id); ?>"
                                                value="absent">
                                            <label class="form-check-label d-inline" for="absent<?php echo e($student->id); ?>">Absent</label>
                                        </div>
                                        <div class="form-check form-check-inline d-inline">
                                            <input class="form-check-input d-inline" type="radio"
                                                name="attendance[<?php echo e($student->id); ?>]" id="leave<?php echo e($student->id); ?>"
                                                value="leave">
                                            <label class="form-check-label d-inline d-inline" for="leave<?php echo e($student->id); ?>">Leave</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>



                    <button type="submit" class="btn btn-primary mt-3">Submit</button>

                </form>

                <div class="row">
                    <div class="col">

                        
                    </div>
                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/attendence/create.blade.php ENDPATH**/ ?>