
<?php /**PATH F:\laravel\sms2\resources\views/components/right-sidebar.blade.php ENDPATH**/ ?>