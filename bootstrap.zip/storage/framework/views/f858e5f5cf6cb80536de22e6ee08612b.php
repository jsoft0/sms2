<?php $__env->startPush('js'); ?>


<script>
    $(document).ready(function() {
        $('select[name="select-class"]').change(function() {
            var classId = $(this).val();
            if (classId) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('attendence.sections')); ?>",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        class_id: classId
                    },
                    success: function(res) {
                        if (res) {
                            $("#sectionContainer").html(res);
                        } else {
                            $("#sectionContainer").empty();
                        }
                    }
                });
            } else {
                $("#sectionContainer").empty();
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">

        <div class="col-12 mt-3">
            <h2>Attendance Report</h2>
            <form action="<?php echo e(route('attendence.index')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <div class="form-row">

                    <div class="col-md-4">
                        <select class="custom-select" name="select-class">
                            <option selected>Select Class</option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($class->id); ?>"><?php echo e($class->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4" id="sectionContainer">
                        <select class="custom-select" name="select-section">
                            <option selected>Select Section</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="date" name="attendance_date" class="form-control">
                    </div>
                    <div class="col-12 mt-3">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container">


    <div class="row">

        <div class="col-12">
            <form action="">
                <div class="form-row">
                    <!-- Add this code below your form to display the student list only when data is available -->
                    <?php if(isset($attendanceData) && count($attendanceData) > 0): ?>
                        <div class="mt-3 col-12">
                            <h2>Attendance Data</h2>
                            <table class="table table-bordered w-100">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Student Name</th>
                                        <th>Status</th>
                                        <!-- Add more columns based on your data structure -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $attendanceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($attendance->student->name); ?></td>
                                            <td><?php echo e($attendance->status); ?></td>
                                            <!-- Add more columns based on your data structure -->
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php elseif(isset($attendanceData) && count($attendanceData) == 0): ?>
                        <div class="mt-3 col-12">
                            <p>No attendance data available for the selected criteria.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/attendence/index.blade.php ENDPATH**/ ?>