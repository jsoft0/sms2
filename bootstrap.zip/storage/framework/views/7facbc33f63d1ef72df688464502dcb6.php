<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Student Details</h4>
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>Name</td>
                                        <td><?php echo e($student->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Registration Number</td>
                                        <td><?php echo e($student->reg_no); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Roll Number</td>
                                        <td><?php echo e($student->roll_no); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Date of Birth</td>
                                        <td><?php echo e($student->date_of_birth); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Class Group</td>
                                        <td><?php echo e($student->classGroup->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Section</td>
                                        <td><?php echo e($student->section->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Picture</td>
                                        <td><img src="<?php echo e(asset('storage/' . $student->picture)); ?>" alt="Student Picture" class="img-thumbnail" style="max-width: 200px;"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/students/show.blade.php ENDPATH**/ ?>