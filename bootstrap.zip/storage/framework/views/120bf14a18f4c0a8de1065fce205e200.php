<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script
    src="https://code.jquery.com/jquery-3.7.1.min.js"
    integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
    crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>
    <script>
        $('#classTable').dataTable();
    </script>
<?php $__env->stopPush(); ?>



<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"> Class List</h4>
                    <div class="table-responsive">
                        <table class="table table-hover display" id="classTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Teacher ID</th>
                                    <th>Teacher Name</th>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Subject</th>
                                    <th>Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $classGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($classGroup->teacher_id); ?></td>
                                        <td><?php echo e($classGroup->name); ?></td>
                                        <td><?php echo e($classGroup->class); ?></td>
                                        <td><?php echo e($classGroup->section); ?></td>
                                        <td><?php echo e($classGroup->subject); ?></td>
                                        <td>

                                            <div class="dropdown">
                                                <button class="btn" type="button" data-toggle="dropdown"
                                                    aria-expanded="false">
                                                    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>


                                                </button>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('class.edit', $classGroup->id)); ?>">Edit</a>

                                                    <a class="dropdown-item" href="#">

                                                        <form action="<?php echo e(route('class.destroy', $classGroup->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-primary">Delete</button>

                                                        </form>
                                                    </a>

                                                </div>
                                            </div>


                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/class/index.blade.php ENDPATH**/ ?>