<?php $__env->startSection('content'); ?>

<div class="content-wrapper ">
    
        <div class="row grid-margin stretch-card">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">

                        <h2>Edit Section</h2>

                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('sections.update', $section->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($section->name); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="class_group_id">Class Group</label>
                                <select name="class_group_id" id="class_group_id" class="form-control" required>
                                    <?php $__currentLoopData = $classGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($classGroup->id); ?>" <?php echo e($classGroup->id == $section->class_group_id ? 'selected' : ''); ?>>
                                            <?php echo e($classGroup->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/sections/edit.blade.php ENDPATH**/ ?>