<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">



        <div class="row">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Class</h4>
                        <form>
                            <div class="row">
                                <div class="col-md-3">

                                    <label for="t_name">Teacher Name *</label>
                                    <input id="t_name" type="text" class="form-control" placeholder="First Name">

                                </div>

                                <div class="col-md-3">

                                    <label for="f_name">ID No *</label>
                                    <input id="f_name" type="number" class="form-control" placeholder="Last Name">
                                </div>


                                <div class="col-md-3 ">
                                    <label for="name">Gender *</label>
                                    <select class="form-control">
                                        <option>Default select</option>
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Others</option>

                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label for="name">Class *</label>
                                    <select class="form-control">
                                        <option>Default select</option>
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Others</option>

                                    </select>
                                </div>


                                <div class="col-md-3 mt-3">
                                    <label for="name">Subject *</label>
                                    <select class="form-control">
                                        <option>Default select</option>
                                        <option>English</option>
                                        <option>Math</option>
                                        <option>General Science</option>

                                    </select>
                                </div>

                                <div class="col-md-3 mt-3">
                                    <label for="name">Section *</label>
                                    <select class="form-control">
                                        <option>Default select</option>
                                        <option>A</option>
                                        <option>B</option>
                                        <option>C</option>

                                    </select>
                                </div>

                                <div class="col-md-3 mt-3">

                                    <label for="time">Time</label>
                                    <input id="time" type="text" class="form-control" placeholder="Time">
                                </div>

                                <div class="col-md-3 mt-3">

                                    <label for="date">Date</label>
                                    <input id="date" type="date" class="form-control" placeholder="Time">
                                </div>

                                <div class="col-md-3 mt-3">

                                    <label for="t_name">Phone *</label>
                                    <input id="t_name" type="number" class="form-control" placeholder="Phone No">

                                </div>


                                <div class="col-md-3 mt-3">

                                    <label for="t_name">E-Mail </label>
                                    <input id="t_name" type="email" class="form-control" placeholder="Phone No">

                                </div>

                                <div class="col-12 mt-3">

                                    <button class="btn btn-primary" type="submit">Save</button>
                                    <button class="btn btn-primary" type="submit">Reset</button>

                                </div>








                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\sms2\resources\views/class/add-class.blade.php ENDPATH**/ ?>